package org.softuni.pathfinder.domain.entities.enums;

public enum CategoryName {
    PEDESTRIAN, BICYCLE, MOTORCYCLE, CAR
}
