package org.softuni.pathfinder.domain.entities.enums;

public enum UserRole {
    USER,MODERATOR,ADMIN
}
