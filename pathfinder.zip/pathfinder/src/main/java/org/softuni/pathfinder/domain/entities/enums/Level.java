package org.softuni.pathfinder.domain.entities.enums;

public enum Level {
    BEGINNER,INTERMEDIATE,ADVANCED
}
